package com.example.movesearchtestapp

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MovieSearchApplication: Application() {

}